// CalendarAgent: puts the discharge papers' appointments and prescriptions on the family calendar,
// and explains every decision. Deterministic and local (no AI request), so it runs every time papers
// are loaded. It never invents a date, time or dose: anything the papers leave unclear is still shown,
// marked "confirm with your care team" with the reason, and anything without an exact date is skipped
// with the reason logged.
import { addDays } from './briefing.js';
import { reasonText } from '../clinical/render.js';

const clip = (s, n) => (s.length > n ? s.slice(0, n - 1) + '…' : s);
const why = item => [...new Set((item.reasons || []).map(r => reasonText(r.code, 'en')))].join(' ');
const days = d => (d?.value ? (d.unit === 'week' ? d.value * 7 : d.unit === 'day' ? d.value : null) : null);

/**
 * @param plan  output of extractInstructions
 * @param opts  { today: 'YYYY-MM-DD', source: filename }
 * @returns { entries, log } — entries: visits ({kind:'visit'}, same shape as family visits) and
 *          medicine courses ({kind:'med'|'stop'}); log: [{ action: 'added'|'flagged'|'skipped', what, why, source, page }]
 */
export function syncCalendarFromPlan(plan, { today, source = '' } = {}) {
  const entries = [], log = [];
  for (const it of plan?.items || []) {
    const quote = clip(String(it.provenance?.text || it.text || ''), 240), page = it.provenance?.page ?? null;
    const needsConfirm = it.clarity !== 'clear' || Boolean(it.highRisk);
    if (it.category === 'appointment' || it.category === 'test') {
      if (!it.date) {
        log.push({ action: 'skipped', what: it.category === 'test' ? 'Test' : 'Follow-up visit', why: it.relative ? `Your papers say “${it.relative.value} ${it.relative.unit}(s)” but give no exact date, so nothing was put on a day. Ask your care team for the date.` : 'Your papers give no date for this visit. Ask your care team when it is.', source: quote, page });
        continue;
      }
      const missing = [!it.time && 'time', !it.location && 'place'].filter(Boolean);
      entries.push({ id: `agent-${it.id}`, by: 'agent', kind: 'visit', itemId: it.id, who: '', title: it.category === 'test' ? 'Test (from your discharge papers)' : 'Follow-up visit (from your discharge papers)', doctor: it.with || '', date: it.date, time: it.time || null, place: it.location || '', notes: quote, remind: it.time ? [1440, 60] : [], needsConfirm, confirmWhy: needsConfirm ? why(it) || `The ${missing.join(' and ')} ${missing.length > 1 ? 'are' : 'is'} not in your papers.` : '', page, source });
      log.push({ action: needsConfirm ? 'flagged' : 'added', what: `${it.category === 'test' ? 'Test' : 'Follow-up visit'} on ${it.date}${it.time ? ` at ${it.time}` : ''}`, why: needsConfirm ? `Added, but please confirm: ${why(it) || 'details are missing.'}${missing.length ? ` Missing: ${missing.join(', ')}.` : ''}` : `Your papers give the date${it.time ? ', time' : ''}${it.location ? ' and place' : ''}. Reminders set for 1 day and 1 hour before.`, source: quote, page });
    } else if (it.category === 'medication') {
      const name = it.name || 'Medicine (name not clear)';
      if (['STOP', 'HOLD'].includes(it.status)) {
        entries.push({ id: `agent-${it.id}`, by: 'agent', kind: 'stop', itemId: it.id, title: name, from: today, to: null, needsConfirm: it.clarity !== 'clear', confirmWhy: it.clarity !== 'clear' ? why(it) : '', notes: quote, page, source });
        log.push({ action: it.clarity === 'clear' ? 'added' : 'flagged', what: `Do not take: ${name}`, why: `Your papers say to ${it.status === 'STOP' ? 'stop' : 'hold'} it, so it is shown as “do not take” from today.${it.clarity !== 'clear' ? ` Please confirm: ${why(it)}` : ''}`, source: quote, page });
        continue;
      }
      const from = it.start?.date || today, n = days(it.duration);
      const to = n && it.start?.date ? addDays(it.start.date, n - 1) : null;
      const startUnknown = Boolean(n && !it.start?.date);
      const prn = Boolean(it.frequency?.prn);
      entries.push({ id: `agent-${it.id}`, by: 'agent', kind: 'med', itemId: it.id, title: name, from, to, prn, timesPerDay: it.frequency?.timesPerDay || null, needsConfirm, confirmWhy: needsConfirm ? why(it) : startUnknown ? 'Your papers don’t say which day this course started, so the last day is not shown.' : '', notes: quote, page, source });
      const span = to ? `from ${from} to ${to}` : `from ${from}${startUnknown ? ' (end day unknown)' : ''}`;
      log.push({ action: needsConfirm ? 'flagged' : 'added', what: `${prn ? 'Only when needed' : 'Medicine'}: ${name}`, why: needsConfirm ? `Shown on your calendar ${span} with a warning. Please confirm with your care team before relying on it: ${why(it)}` : `Shown on your calendar ${span}${prn ? ' as “only when needed”' : ''}.${startUnknown ? ' Your papers don’t say which day it started, so ask when it ends.' : ''}`, source: quote, page });
    }
  }
  return { entries, log };
}

/** Medicine courses active on a date. */
export function medsOn(entries, date) {
  return entries.filter(e => (e.kind === 'med' || e.kind === 'stop') && date >= e.from && (!e.to || date <= e.to));
}
